package com.accumenta.clinic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.accumenta.clinic.dtos.ResponseWrapper;
import com.accumenta.clinic.models.Clinic;
import com.accumenta.clinic.service.ClinicService;

@RestController
@RequestMapping("/api/v1/")
public class ClinicController 
{
	@Autowired
	private ClinicService clinicService;
	
	@PostMapping(value="saveClinic",produces="application/json")
	public ResponseEntity<ResponseWrapper> saveClinic(@RequestBody Clinic clinic)
	{
		 Clinic dbClinic=this.clinicService.addClinic(clinic);
		 return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(dbClinic));
	}
	
	@GetMapping(value="getClinic",produces="application/json")
	public ResponseEntity<ResponseWrapper> getClinic(@RequestParam long clinicId,@RequestBody Clinic clinic)
	{
		Clinic dbClinic=this.clinicService.getClinic(clinicId, clinic);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(dbClinic));
	}
	
	@DeleteMapping(value="delClinic",produces="application/json")
	public ResponseEntity<ResponseWrapper> delClinic(@RequestParam long clinicId)
	{
		boolean dbClinic=this.clinicService.delClinic(clinicId);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(dbClinic));
	}

}
