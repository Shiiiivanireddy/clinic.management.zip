package com.accumenta.clinic.service;


import com.accumenta.clinic.models.Services;

public interface ServicesService 
{
	Services addServices(String clinicId,Services services);
	Services getServices(long serviceId);
	boolean delServices(long serviceId);

}
