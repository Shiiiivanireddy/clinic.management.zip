package com.accumenta.clinic.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accumenta.clinic.exception.ClinicAlreadyExistsException;
import com.accumenta.clinic.exception.ClinicIdAlreadyExistsException;
import com.accumenta.clinic.models.Clinic;
import com.accumenta.clinic.repository.ClinicRepository;
import com.accumenta.clinic.service.ClinicService;
@Service
public class ClinicServiceimpl implements ClinicService
{
	@Autowired
	private ClinicRepository clinicRepository;

	@Override
	public Clinic addClinic(Clinic clinic) {
		Clinic dbClinic=this.clinicRepository.findById(clinic.getClinicId()).orElse(null);
		if (dbClinic==null)
		{
			return this.clinicRepository.save(clinic);
		}
		else
		{
			throw new ClinicAlreadyExistsException("Clinic Already Exists");
		}   
	}

	@Override
	public Clinic getClinic(long clinicId,Clinic clinic) {
		Clinic dbClinic=this.clinicRepository.findById(clinicId).get();
		if (dbClinic!=null) 
		{
			return this.clinicRepository.findById(clinicId).get();
			
		}
		else
		{
			throw new ClinicIdAlreadyExistsException("ClinicId Already Exists");
		}
	}

	@Override
	public boolean delClinic(long clinicId) {
		Clinic dbClinic=this.clinicRepository.findById(clinicId).get();
		if (dbClinic!=null) 
		{
			  this.clinicRepository.delete(dbClinic);
			  return true;
			
			
		}
		else
		{
			throw new ClinicIdAlreadyExistsException("ClinicId Already Exists");
		}
	}

}
