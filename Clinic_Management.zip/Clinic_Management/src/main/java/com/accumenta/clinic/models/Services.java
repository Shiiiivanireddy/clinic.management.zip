package com.accumenta.clinic.models;

import com.accumenta.clinic.enumerations.ServiceOffered;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class Services 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long serviceId;
	
	private String serviceName;
	
	private String serviceCode;
	
	private String serviceDescription;
	private double averagePrice;
	private boolean isActive;
	
	@Enumerated(EnumType.STRING)
	private ServiceOffered serviceOffered;
	
	@ManyToOne
	@JoinColumn(name="clinic_id")
	private Clinic clinic;
}
