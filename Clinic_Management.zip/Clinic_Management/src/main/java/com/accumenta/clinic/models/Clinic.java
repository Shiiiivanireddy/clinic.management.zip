package com.accumenta.clinic.models;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Clinic 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long clinicId;
	
	private String clinicName;
	
	private String bussinessName;
	
	private String streetAddressName;
	
	private String city;
	private String state;
	private String country;
	
	private String zipcode;
	
	private double latitute;
	private double longitute;
	private LocalDate date;
	

}
