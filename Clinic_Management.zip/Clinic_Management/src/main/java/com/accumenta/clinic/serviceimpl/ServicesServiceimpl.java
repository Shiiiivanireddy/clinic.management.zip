package com.accumenta.clinic.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accumenta.clinic.exception.ServiceIdAlreadyExistsException;
import com.accumenta.clinic.exception.ServicesAlreadyExistsException;
import com.accumenta.clinic.models.Clinic;
import com.accumenta.clinic.models.Services;
import com.accumenta.clinic.repository.ClinicRepository;
import com.accumenta.clinic.repository.ServicesRepository;
import com.accumenta.clinic.service.ServicesService;
@Service
public class ServicesServiceimpl implements ServicesService
{
	@Autowired
	private ServicesRepository serviesRepository;
	
	@Autowired
	private ClinicRepository clinicRepository;

	@Override
	public Services addServices(String clinicName,Services services) {
		Services dbServices=this.serviesRepository.findById(services.getServiceId()).orElse(null);
		Clinic dbClinic=this.clinicRepository.findByName(clinicName);
		if (dbServices==null) 
		{
			services.setClinic(dbClinic);
			return this.serviesRepository.save(services);
			
		}
		else
		{
			throw new ServicesAlreadyExistsException("Services Already Exists");
		}
	}

	@Override
	public Services getServices(long serviceId) {
		Services dbServices=this.serviesRepository.findById(serviceId).get();
		if (dbServices!=null) 
		{
			return this.serviesRepository.findById(serviceId).get();
			
		}
		else
		{
			throw new ServiceIdAlreadyExistsException("Services Already Exists");
		}
	}

	@Override
	public boolean delServices(long serviceId) {
		Services dbService=this.serviesRepository.findById(serviceId).get();
		if (dbService!=null)
		{
			this.serviesRepository.delete(dbService);
			return true;
		}
		else
		{
			throw new ServiceIdAlreadyExistsException("Services Already Exists");
		}
	}

}
