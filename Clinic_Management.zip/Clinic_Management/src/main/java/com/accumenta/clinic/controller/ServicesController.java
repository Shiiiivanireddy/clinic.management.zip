package com.accumenta.clinic.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.accumenta.clinic.dtos.ResponseWrapper;
import com.accumenta.clinic.models.Services;
import com.accumenta.clinic.service.ServicesService;

@RestController
@RequestMapping("/api/v1/")
public class ServicesController 
{
	@Autowired
	private ServicesService servicesService;
	
	@PostMapping(value="saveServices",produces="application/json")
	public ResponseEntity<ResponseWrapper> saveServices(@RequestParam String clinicName,@RequestBody Services services)
	{
		Services dbServices=this.servicesService.addServices(clinicName, services);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(clinicName));
	}
	
	@GetMapping(value="getServices",produces="application/json")
	public ResponseEntity<ResponseWrapper> getServices(@RequestParam long serviceId)
	{
		Services dbServices=this.servicesService.getServices(serviceId);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(dbServices));
	}
	
	@DeleteMapping(value="delService",produces="application/json")
	public ResponseEntity<ResponseWrapper> delService(@RequestParam long serviceId)
	{
		boolean dbServices=this.servicesService.delServices(serviceId);
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(dbServices));
		
	}
}
