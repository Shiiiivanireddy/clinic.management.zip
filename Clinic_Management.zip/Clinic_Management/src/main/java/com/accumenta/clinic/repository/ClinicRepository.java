package com.accumenta.clinic.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.accumenta.clinic.models.Clinic;

public interface ClinicRepository extends JpaRepository<Clinic, Long>
{
	@Query("select c from Clinic c where c.clinicName=:clinicName")
	Clinic findByName(@Param("clinicName") String clinicName);
}
