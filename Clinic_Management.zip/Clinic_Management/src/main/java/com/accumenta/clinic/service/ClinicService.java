package com.accumenta.clinic.service;

import com.accumenta.clinic.models.Clinic;

public interface ClinicService 
{
	Clinic addClinic(Clinic clinic);
	Clinic getClinic(long clinicId,Clinic clinic);
	boolean delClinic(long clinicId);
}
