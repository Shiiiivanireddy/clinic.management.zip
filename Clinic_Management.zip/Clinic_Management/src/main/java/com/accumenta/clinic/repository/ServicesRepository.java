package com.accumenta.clinic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.accumenta.clinic.models.Services;

public interface ServicesRepository extends JpaRepository<Services, Long>
{
	@Query("select s from Services s where s.serviceName=:serviceName")
	Services findByName(@Param("serviceName") String serviceName);
}
