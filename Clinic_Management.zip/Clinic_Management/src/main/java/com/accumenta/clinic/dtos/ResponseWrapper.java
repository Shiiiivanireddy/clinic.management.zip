package com.accumenta.clinic.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseWrapper<T> 
{

	private T object;
	private String message;
	public ResponseWrapper(T object) {
		super();
		this.object = object;
	}
	public ResponseWrapper(String message) {
		super();
		this.message = message;
	}
	
	
	

}
