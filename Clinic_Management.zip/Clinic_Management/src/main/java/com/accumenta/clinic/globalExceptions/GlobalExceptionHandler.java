package com.accumenta.clinic.globalExceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.accumenta.clinic.dtos.ResponseWrapper;
import com.accumenta.clinic.exception.ClinicAlreadyExistsException;
import com.accumenta.clinic.exception.ClinicIdAlreadyExistsException;
import com.accumenta.clinic.exception.ServiceIdAlreadyExistsException;
import com.accumenta.clinic.exception.ServicesAlreadyExistsException;

@ControllerAdvice
public class GlobalExceptionHandler
{
	@ExceptionHandler(ClinicAlreadyExistsException.class)
	 ResponseEntity<ResponseWrapper> clinicAlreadyExistsException(ClinicAlreadyExistsException ex)
	 {
		 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseWrapper<>(ex));
	 }
	@ExceptionHandler(ClinicIdAlreadyExistsException.class)
	ResponseEntity<ResponseWrapper> ClinicIdAlreadyExistsException(ClinicIdAlreadyExistsException ex)
	{
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseWrapper<>(ex));
	}
	@ExceptionHandler(ServicesAlreadyExistsException.class)
	ResponseEntity<ResponseWrapper> ServicesAlreadyExistsException(ServicesAlreadyExistsException ex)
	{
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseWrapper<>(ex));
	}
	@ExceptionHandler(ServiceIdAlreadyExistsException.class)

	ResponseEntity<ResponseWrapper> ServiceIdAlreadyExistsException(ServiceIdAlreadyExistsException ex)
	{
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseWrapper<>(ex));
	}
	
}
