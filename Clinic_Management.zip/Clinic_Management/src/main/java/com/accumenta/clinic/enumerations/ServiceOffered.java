package com.accumenta.clinic.enumerations;

public enum ServiceOffered 
{
	Consultation, Xray,BloodTest,CovidTest,MRIScan
}
